<?php
  

session_start();
require("../confige/social_post.php");

$id=$_SESSION['id'];

$get_camp_name=$_POST['camp_name'];
$get_data=$_POST['camp_data'];


$json_data=json_decode($get_data);


foreach($json_data as $value){


$flg_send=1;








	$isrt_data_que="insert into post_que_data VALUES('$id','$value','$get_camp_name','$flg_send')";
	
	
	if ($social_post_conn->query($isrt_data_que) === TRUE) {
  echo 1;
}	






}




?>
