<?php



session_start();
require("../confige/social_post.php");




$camp_id=$_POST['camp_name'];

$url_add=$_POST['url'];


$isrt_url_data="insert into post_data_url VALUES ('$camp_id','$url_add')";


echo $isrt_url_data;



if ($social_post_conn->query($isrt_url_data) === TRUE) {
  echo 1;
}




?>
