<?php

require("../confige/social_post.php");
session_start();


$id=$_SESSION['id'];
$token_id=$_POST['token_id'];
$arr_camp_name_2=array();
$sel_query_dt_tok="select camp_name from post_que_data where token='".$token_id."' and id='".$id."'";


$result = $social_post_conn->query($sel_query_dt_tok);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    
array_push($arr_camp_name_2,$row['camp_name']);


  }
} else {
  echo 0;
}

$jsn_data=json_encode($arr_camp_name_2);

echo $jsn_data;
?>
