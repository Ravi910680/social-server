<?php
session_start();

require("../confige/social_post.php");


$token_id=$_POST['token_id'];

$post_id=$_POST['post_id'];

$del_post_query="DELETE  from post_que_data where token='".$token_id."' and camp_name='".$post_id."'";

if ($social_post_conn->query($del_post_query) === TRUE) {
  echo 1;
} 


?>
