<?php
session_start();

require("../confige/social_post.php");

$get_camp_data=$_POST['get_jsn'];

$arr_of_camp_data=array();

$camp_id_arr=json_decode($get_camp_data);



if(!is_null($camp_id_arr)){

foreach ($camp_id_arr as $key => $value){

$sel_camp_data_query="select * from camp_soc_hy where post_name='".$value."'";



$result = $social_post_conn->query($sel_camp_data_query);


  // output data of each row
  while($row = $result->fetch_assoc()) {
    




array_push($arr_of_camp_data, $row);



  }
 



}

}

$jsn_camp_dt=json_encode($arr_of_camp_data);
echo $jsn_camp_dt;

?>
